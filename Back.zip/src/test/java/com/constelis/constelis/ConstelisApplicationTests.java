package com.constelis.constelis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConstelisApplicationTests {

	@Test
	void contextLoads() {
	}

}
